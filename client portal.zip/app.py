import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import json
from io import BytesIO
from st_aggrid import AgGrid, GridOptionsBuilder
import base64
import tempfile
import os
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='client_portal.log'
)

# ==============================================
# CLIENT PORTAL COMPONENT
# ==============================================

def client_portal(user_info):
    """Enhanced client portal with all requested features"""
    st.set_page_config(
        page_title=f"{user_info['client_org']} Portal",
        layout="wide",
        page_icon="🏥"
    )
    
    # Custom CSS for styling
    st.markdown("""
    <style>
        .metric-card {
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            background-color: #f8f9fa;
            margin-bottom: 20px;
        }
        .metric-title {
            font-size: 14px;
            color: #6c757d;
            margin-bottom: 5px;
        }
        .metric-value {
            font-size: 24px;
            font-weight: bold;
            color: #2c3e50;
        }
        .card {
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .tab-content {
            padding-top: 20px;
        }
        .stDataFrame {
            border-radius: 10px;
        }
        .stPlotlyChart {
            border-radius: 10px;
        }
    </style>
    """, unsafe_allow_html=True)
    
    # Sidebar configuration
    with st.sidebar:
        st.image("https://via.placeholder.com/200x50?text=Client+Logo", use_container_width=True)
        st.markdown(f"### {user_info['client_org']}")
        st.markdown(f"Welcome, **{user_info['name']}**")
        st.markdown("---")
        
        # Navigation
        st.markdown("### Navigation")
        page = st.radio(
            "Go to",
            ["Dashboard", "Advanced Analysis", "Claims Prediction", "Fraud Detection", "Reports"],
            label_visibility="collapsed"
        )
        
        st.markdown("---")
        st.markdown("### Support")
        st.button("Contact Support")
        if st.button("Logout"):
            st.session_state.authenticated = False
            st.rerun()
    
    # Main content area
    st.title(f"🏥 {user_info['client_org']} Healthcare Claims Portal")
    
    if page == "Dashboard":
        render_default_dashboard(user_info)
    elif page == "Advanced Analysis":
        render_advanced_analysis(user_info)
    elif page == "Claims Prediction":
        render_claims_prediction(user_info)
    elif page == "Fraud Detection":
        render_fraud_detection(user_info)
    elif page == "Reports":
        render_reporting(user_info)

# ==============================================
# DEFAULT DASHBOARD
# ==============================================

def render_default_dashboard(user_info):
    """Render the default dashboard with key metrics"""
    st.header("📊 Claims Dashboard Overview")
    
    # Check if data is loaded
    if 'claims_data' not in st.session_state or st.session_state.claims_data is None:
        st.warning("Please upload claims data first")
        return
    
    data = st.session_state.claims_data
    
    # Filter data for this client
    client_data = data[data['employer'] == user_info['client_org']].copy()
    
    if client_data.empty:
        st.warning("No claims data found for your organization")
        return
    
    # Row 1: Summary Metrics
    st.subheader("Key Metrics")
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown("""
        <div class="metric-card">
            <div class="metric-title">📊 Total Claims Submitted</div>
            <div class="metric-value">{:,}</div>
        </div>
        """.format(len(client_data)), unsafe_allow_html=True)
    
    with col2:
        total_amount = client_data['amount'].sum()
        st.markdown("""
        <div class="metric-card">
            <div class="metric-title">💰 Total Claims Amount</div>
            <div class="metric-value">KES {:,.2f}</div>
        </div>
        """.format(total_amount), unsafe_allow_html=True)
    
    with col3:
        avg_amount = client_data['amount'].mean()
        st.markdown("""
        <div class="metric-card">
            <div class="metric-title">🧾 Average Claim Amount</div>
            <div class="metric-value">KES {:,.2f}</div>
        </div>
        """.format(avg_amount), unsafe_allow_html=True)
    
    with col4:
        fraud_count = client_data['fraud_flag'].sum() if 'fraud_flag' in client_data.columns else 0
        st.markdown("""
        <div class="metric-card">
            <div class="metric-title">⚠️ Potential Fraud Cases</div>
            <div class="metric-value">{:,}</div>
        </div>
        """.format(fraud_count), unsafe_allow_html=True)
    
    # Row 2: Visualizations
    st.subheader("Claims Overview")
    tab1, tab2, tab3 = st.tabs(["Claims by Category", "Claims by Cost Centre", "Service Utilization"])
    
    with tab1:
        if 'category' in client_data.columns:
            category_data = client_data.groupby('category')['amount'].sum().reset_index()
            fig = px.pie(
                category_data,
                names='category',
                values='amount',
                title='🧾 Claims Amount by Category',
                hole=0.4
            )
            fig.update_traces(textposition='inside', textinfo='percent+label')
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.warning("Category information not available")
    
    with tab2:
        if 'cost_centre' in client_data.columns:
            cost_centre_data = client_data.groupby('cost_centre')['amount'].sum().reset_index()
            fig = px.bar(
                cost_centre_data,
                x='cost_centre',
                y='amount',
                title='💼 Claims Amount by Cost Centre',
                color='cost_centre'
            )
            fig.update_layout(xaxis_title="Cost Centre", yaxis_title="Total Amount (KES)")
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.warning("Cost centre information not available")
    
    with tab3:
        if 'benefit_type' in client_data.columns:
            benefit_data = client_data['benefit_type'].value_counts().reset_index()
            benefit_data.columns = ['Benefit Type', 'Count']
            fig = px.bar(
                benefit_data,
                x='Benefit Type',
                y='Count',
                title='🧮 Service Utilization by Benefit Type',
                color='Benefit Type'
            )
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.warning("Benefit type information not available")
    
    # Row 3: Top Claimants
    st.subheader("🧑‍⚕️ Top Claimants")
    if 'employee_id' in client_data.columns:
        top_claimants = client_data.groupby('employee_id')['amount'].sum().nlargest(10).reset_index()
        top_claimants.columns = ['Employee ID', 'Total Claims Amount']
        
        # Display as both table and chart
        col1, col2 = st.columns([1, 2])
        
        with col1:
            st.dataframe(
                top_claimants.style.format({'Total Claims Amount': 'KES {:,.2f}'}),
                height=400
            )
        
        with col2:
            fig = px.bar(
                top_claimants,
                x='Employee ID',
                y='Total Claims Amount',
                title='Top 10 Claimants by Total Amount',
                color='Total Claims Amount',
                color_continuous_scale='Bluered'
            )
            st.plotly_chart(fig, use_container_width=True)
    else:
        st.warning("Employee information not available")

# ==============================================
# ADVANCED ANALYSIS
# ==============================================

def render_advanced_analysis(user_info):
    """Render the advanced analysis section"""
    st.header("🔍 Advanced Claims Analysis")
    
    # Check if data is loaded
    if 'claims_data' not in st.session_state or st.session_state.claims_data is None:
        st.warning("Please upload claims data first")
        return
    
    data = st.session_state.claims_data
    
    # Filter data for this client
    client_data = data[data['employer'] == user_info['client_org']].copy()
    
    if client_data.empty:
        st.warning("No claims data found for your organization")
        return
    
    # Tabbed interface
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "🔄 Claims Distribution",
        "🕒 Temporal Analysis",
        "⚙️ Provider Efficiency",
        "🧬 Diagnosis Patterns",
        "🗺️ Geospatial Heatmap"
    ])
    
    with tab1:
        st.subheader("Claim Distribution Analysis")
        
        # Get available categorical columns
        cat_cols = [col for col in client_data.columns if client_data[col].dtype in ['object', 'category']]
        
        if not cat_cols:
            st.warning("No categorical columns found for distribution analysis")
        else:
            col1, col2 = st.columns(2)
            
            with col1:
                # Default to 'category' if available, otherwise first category
                default_category = 'category' if 'category' in cat_cols else cat_cols[0]
                category = st.selectbox(
                    "Group claims by",
                    options=cat_cols,
                    index=cat_cols.index(default_category) if default_category in cat_cols else 0
                )
                
                # Add interactive filters
                filter_col = st.selectbox(
                    "Filter by",
                    options=['None'] + cat_cols,
                    key='dist_filter_select'
                )
                
                if filter_col != 'None':
                    filter_values = st.multiselect(
                        f"Select {filter_col} values",
                        options=client_data[filter_col].unique(),
                        key='dist_filter_values_select'
                    )
                    if filter_values:
                        client_data = client_data[client_data[filter_col].isin(filter_values)]
            
            with col2:
                # Default to 'Sum of Amount'
                metric = st.selectbox(
                    "Analysis metric",
                    options=['Count', 'Sum of Amount', 'Average Amount'],
                    index=1  # Default to 'Sum of Amount'
                )
            
            # Prepare data based on selections
            if metric == 'Count':
                dist_data = client_data[category].value_counts().reset_index()
                dist_data.columns = [category, 'Count']
                y_metric = 'Count'
            else:
                # Ensure amount column is numeric
                if 'amount' in client_data.columns:
                    client_data['amount'] = pd.to_numeric(client_data['amount'], errors='coerce')
                    
                    if metric == 'Sum of Amount':
                        dist_data = client_data.groupby(category)['amount'].sum().reset_index()
                        dist_data.columns = [category, 'Total Amount']
                        y_metric = 'Total Amount'
                    elif metric == 'Average Amount':
                        dist_data = client_data.groupby(category)['amount'].mean().reset_index()
                        dist_data.columns = [category, 'Average Amount']
                        y_metric = 'Average Amount'
                else:
                    st.warning("No amount column found for amount calculations")
                    return
            
            # Create interactive visualization
            fig = px.bar(
                dist_data,
                x=category,
                y=y_metric,
                title=f"Claim Distribution by {category}",
                hover_data=[y_metric],
                color=category,
                text=y_metric
            )
            
            # Add horizontal line for average if showing amounts
            if 'Amount' in metric and 'amount' in client_data.columns:
                avg_value = client_data['amount'].mean() if metric == 'Average Amount' else client_data['amount'].sum()/len(dist_data)
                fig.add_hline(
                    y=avg_value,
                    line_dash="dash",
                    line_color="red",
                    annotation_text=f"Overall {'Average' if metric == 'Average Amount' else 'Mean per Category'}",
                    annotation_position="top left"
                )
            
            st.plotly_chart(fig, use_container_width=True)
    
    with tab2:
        st.subheader("Temporal Claim Patterns")
        
        # Check for date column
        if 'date' in client_data.columns:
            # Convert to datetime if needed
            if not pd.api.types.is_datetime64_any_dtype(client_data['date']):
                client_data['date'] = pd.to_datetime(client_data['date'], errors='coerce')
            
            # Remove rows with invalid dates
            client_data = client_data[client_data['date'].notna()]
            
            if client_data.empty:
                st.warning("No valid dates found for temporal analysis")
            else:
                # Temporal aggregation options
                time_unit = st.selectbox(
                    "Time unit",
                    options=['Day', 'Week', 'Month', 'Quarter', 'Year'],
                    key='time_unit'
                )
                
                # Create temporal aggregation
                client_data['time_period'] = client_data['date'].dt.to_period(
                    time_unit[0].lower()
                ).dt.to_timestamp()
                
                # Ensure amount column is numeric
                if 'amount' in client_data.columns:
                    client_data['amount'] = pd.to_numeric(client_data['amount'], errors='coerce')
                    
                    # Group by time period
                    agg_dict = {
                        'amount': ['sum', 'count', 'mean', 'std']
                    }
                    
                    temporal_data = client_data.groupby('time_period').agg(agg_dict).reset_index()
                    
                    # Flatten multi-index columns
                    temporal_data.columns = [
                        'time_period',
                        'total_amount',
                        'claim_count',
                        'avg_amount',
                        'std_amount'
                    ]
                    
                    # Calculate confidence intervals
                    temporal_data['ci_lower'] = temporal_data['avg_amount'] - 1.96 * temporal_data['std_amount']/np.sqrt(temporal_data['claim_count'])
                    temporal_data['ci_upper'] = temporal_data['avg_amount'] + 1.96 * temporal_data['std_amount']/np.sqrt(temporal_data['claim_count'])
                    
                    # Visualization
                    metric = st.selectbox(
                        "Show metric",
                        options=['Claim Count', 'Total Amount', 'Average Amount'],
                        key='temp_metric'
                    )
                    
                    if metric == 'Claim Count':
                        fig = px.line(
                            temporal_data,
                            x='time_period',
                            y='claim_count',
                            title=f"Claim Count by {time_unit}",
                            labels={'claim_count': 'Number of Claims'},
                            markers=True
                        )
                    elif metric == 'Total Amount':
                        fig = px.line(
                            temporal_data,
                            x='time_period',
                            y='total_amount',
                            title=f"Total Claim Amount by {time_unit}",
                            labels={'total_amount': 'Total Amount (KES)'},
                            markers=True
                        )
                    else:  # Average Amount
                        fig = px.line(
                            temporal_data,
                            x='time_period',
                            y='avg_amount',
                            title=f"Average Claim Amount by {time_unit} with 95% CI",
                            labels={'avg_amount': 'Average Amount (KES)'},
                            markers=True
                        )
                        
                        # Add confidence interval
                        fig.add_trace(
                            go.Scatter(
                                x=temporal_data['time_period'],
                                y=temporal_data['ci_upper'],
                                fill=None,
                                mode='lines',
                                line_color='rgba(255,255,255,0)',
                                showlegend=False,
                                name='Upper CI'
                            )
                        )
                        fig.add_trace(
                            go.Scatter(
                                x=temporal_data['time_period'],
                                y=temporal_data['ci_lower'],
                                fill='tonexty',
                                mode='lines',
                                line_color='rgba(0,100,80,0.2)',
                                showlegend=False,
                                name='Lower CI'
                            )
                        )
                    
                    st.plotly_chart(fig, use_container_width=True)
                else:
                    st.warning("Amount information not available")
        else:
            st.warning("Date information not available")
    
    with tab3:
        st.subheader("Provider Efficiency Analysis")
        
        # Get provider column
        provider_col = 'provider_name' if 'provider_name' in client_data.columns else None
        
        if not provider_col:
            st.warning("Provider information missing for efficiency analysis")
        else:
            # Get amount column
            if 'amount' not in client_data.columns:
                st.warning("Amount information missing for efficiency analysis")
                return
            
            try:
                # Ensure numeric columns are properly formatted
                client_data['amount'] = pd.to_numeric(client_data['amount'], errors='coerce').fillna(0)
                
                # Initialize fraud_flag if it doesn't exist
                if 'fraud_flag' not in client_data.columns:
                    client_data['fraud_flag'] = 0
                else:
                    client_data['fraud_flag'] = pd.to_numeric(client_data['fraud_flag'], errors='coerce').fillna(0)
                
                # Calculate provider statistics
                provider_stats = client_data.groupby(provider_col).agg({
                    'amount': ['sum', 'count', 'mean', 'median'],
                    'fraud_flag': 'mean'
                }).reset_index()
                
                # Flatten multi-index columns
                provider_stats.columns = [
                    provider_col,
                    'Total_Amount',
                    'Total_Claims',
                    'Avg_Amount',
                    'Median_Amount',
                    'Fraud_Rate'
                ]
                
                # Calculate efficiency metrics
                overall_avg = client_data['amount'].mean()
                provider_stats['efficiency_ratio'] = provider_stats['Avg_Amount'] / overall_avg
                provider_stats['cost_per_claim'] = provider_stats['Total_Amount'] / provider_stats['Total_Claims']
                
                # Break-even analysis
                st.write("#### Break-Even Analysis")
                col1, col2 = st.columns(2)
                
                with col1:
                    fixed_costs = st.number_input(
                        "Estimated fixed costs per provider (KES)",
                        min_value=0,
                        value=50000,
                        step=1000
                    )
                
                with col2:
                    variable_cost_rate = st.slider(
                        "Variable cost rate (%)",
                        min_value=0,
                        max_value=100,
                        value=60
                    ) / 100
                
                # Calculate break-even points
                provider_stats['break_even_claims'] = np.ceil(
                    fixed_costs / (provider_stats['Avg_Amount'] * (1 - variable_cost_rate)))
                provider_stats['profitability'] = np.where(
                    provider_stats['Total_Claims'] > provider_stats['break_even_claims'],
                    'Profitable',
                    'Unprofitable'
                )
                
                # Visualization
                fig = px.scatter(
                    provider_stats,
                    x='Total_Claims',
                    y='Avg_Amount',
                    color='profitability',
                    size='Total_Amount',
                    hover_name=provider_col,
                    hover_data=['Fraud_Rate', 'break_even_claims'],
                    title="Provider Cost Efficiency Analysis",
                    labels={
                        'Total_Claims': 'Number of Claims',
                        'Avg_Amount': 'Average Claim Amount (KES)',
                        'Total_Amount': 'Total Amount (KES)'
                    }
                )
                
                # Add break-even line
                if fixed_costs > 0:
                    max_claims = provider_stats['Total_Claims'].max()
                    break_even_line = fixed_costs / (np.linspace(1, max_claims, 100) * (1 - variable_cost_rate))
                    
                    fig.add_trace(
                        go.Scatter(
                            x=np.linspace(1, max_claims, 100),
                            y=break_even_line,
                            mode='lines',
                            line=dict(color='red', dash='dash'),
                            name='Break-Even Line'
                        )
                    )
                
                st.plotly_chart(fig, use_container_width=True)
                
                # Show top/bottom performers
                st.write("#### Provider Performance Ranking")
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write("**Most Efficient Providers**")
                    efficient = provider_stats.sort_values('efficiency_ratio').head(5)
                    st.dataframe(efficient[[provider_col, 'efficiency_ratio', 'Avg_Amount', 'Fraud_Rate']])
                
                with col2:
                    st.write("**Least Efficient Providers**")
                    inefficient = provider_stats.sort_values('efficiency_ratio', ascending=False).head(5)
                    st.dataframe(inefficient[[provider_col, 'efficiency_ratio', 'Avg_Amount', 'Fraud_Rate']])
            
            except Exception as e:
                st.error(f"Error calculating provider statistics: {str(e)}")
    
    with tab4:
        st.subheader("Diagnosis-Treatment Patterns")
        
        # Get diagnosis and treatment columns
        diag_col = 'diagnosis' if 'diagnosis' in client_data.columns else None
        treat_col = 'treatment' if 'treatment' in client_data.columns else None
        
        if not diag_col or not treat_col:
            st.warning("Diagnosis or treatment information missing for pattern analysis")
        else:
            # Create diagnosis-treatment matrix
            diag_treat_matrix = pd.crosstab(
                client_data[diag_col],
                client_data[treat_col],
                normalize='index'
            )
            
            # Filter to top diagnoses and treatments
            top_diag = client_data[diag_col].value_counts().head(20).index
            top_treat = client_data[treat_col].value_counts().head(20).index
            
            filtered_matrix = diag_treat_matrix.loc[top_diag, top_treat]
            
            # Create heatmap
            fig = px.imshow(
                filtered_matrix,
                labels=dict(x="Treatment", y="Diagnosis", color="Frequency"),
                x=filtered_matrix.columns,
                y=filtered_matrix.index,
                aspect="auto",
                color_continuous_scale='Blues'
            )
            
            fig.update_layout(
                xaxis_title="Treatment",
                yaxis_title="Diagnosis",
                height=600
            )
            
            st.plotly_chart(fig, use_container_width=True)
    
    with tab5:
        st.subheader("Geospatial Heatmap")
        
        if 'latitude' in client_data.columns and 'longitude' in client_data.columns:
            # Create density heatmap
            fig = px.density_mapbox(
                client_data,
                lat='latitude',
                lon='longitude',
                z='amount',
                radius=10,
                center=dict(lat=client_data['latitude'].mean(), lon=client_data['longitude'].mean()),
                zoom=10,
                mapbox_style="stamen-terrain",
                title='Claim Density by Location'
            )
            
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.warning("Geospatial coordinates (latitude/longitude) not available in data")

# ==============================================
# CLAIMS PREDICTION
# ==============================================

def render_claims_prediction(user_info):
    """Render the claims prediction section"""
    st.header("🔮 Claims Prediction")
    
    # Check if data is loaded
    if 'claims_data' not in st.session_state or st.session_state.claims_data is None:
        st.warning("Please upload claims data first")
        return
    
    data = st.session_state.claims_data
    
    # Filter data for this client
    client_data = data[data['employer'] == user_info['client_org']].copy()
    
    if client_data.empty:
        st.warning("No claims data found for your organization")
        return
    
    # Tabbed interface
    tab1, tab2, tab3, tab4 = st.tabs([
        "📈 Forecasted Volume",
        "📉 Confidence Intervals",
        "🎛️ Impact Simulation",
        "🧠 Explainability"
    ])
    
    with tab1:
        st.subheader("Forecasted Claims Volume")
        
        if 'date' in client_data.columns and 'amount' in client_data.columns:
            # Convert date and ensure amount is numeric
            client_data['date'] = pd.to_datetime(client_data['date'])
            client_data['amount'] = pd.to_numeric(client_data['amount'], errors='coerce')
            
            # Aggregate by month
            monthly_data = client_data.set_index('date').resample('M')['amount'].sum().reset_index()
            
            # Simple forecasting - in a real app, you'd use a proper forecasting model
            last_date = monthly_data['date'].max()
            forecast_months = st.slider("Months to forecast", 1, 12, 3)
            
            # Generate forecast (simple linear extrapolation for demo)
            forecast_dates = pd.date_range(
                start=last_date + pd.DateOffset(months=1),
                periods=forecast_months,
                freq='M'
            )
            
            # Calculate trend (simple linear regression)
            x = np.arange(len(monthly_data))
            y = monthly_data['amount'].values
            coeffs = np.polyfit(x, y, 1)
            forecast_values = np.polyval(coeffs, np.arange(len(monthly_data), len(monthly_data) + forecast_months))
            
            # Create forecast dataframe
            forecast_data = pd.DataFrame({
                'date': forecast_dates,
                'amount': forecast_values,
                'type': 'Forecast'
            })
            
            # Create historical dataframe
            historical_data = pd.DataFrame({
                'date': monthly_data['date'],
                'amount': monthly_data['amount'],
                'type': 'Historical'
            })
            
            # Combine data
            combined_data = pd.concat([historical_data, forecast_data])
            
            # Create plot
            fig = px.line(
                combined_data,
                x='date',
                y='amount',
                color='type',
                title='Monthly Claims Volume with Forecast',
                labels={'amount': 'Total Amount (KES)', 'date': 'Month'},
                markers=True
            )
            
            # Highlight forecast period
            fig.add_vrect(
                x0=last_date,
                x1=forecast_dates[-1],
                fillcolor="lightgray",
                opacity=0.2,
                line_width=0,
                annotation_text="Forecast Period",
                annotation_position="top left"
            )
            
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.warning("Date or amount information not available for forecasting")
    
    with tab2:
        st.subheader("Prediction Confidence Intervals")
    
    if 'date' in client_data.columns and 'amount' in client_data.columns:
        # Convert date and ensure amount is numeric
        client_data['date'] = pd.to_datetime(client_data['date'])
        client_data['amount'] = pd.to_numeric(client_data['amount'], errors='coerce')
        
        # Aggregate by month
        monthly_data = client_data.set_index('date').resample('M').agg({
            'amount': ['sum', 'count', 'mean', 'std']
        }).reset_index()
        
        # Flatten multi-index columns
        monthly_data.columns = [
            'date',
            'total_amount',
            'claim_count',
            'avg_amount',
            'std_amount'
        ]
        
        # Calculate confidence intervals
        monthly_data['ci_lower'] = monthly_data['avg_amount'] - 1.96 * monthly_data['std_amount'] / np.sqrt(monthly_data['claim_count'])
        monthly_data['ci_upper'] = monthly_data['avg_amount'] + 1.96 * monthly_data['std_amount'] / np.sqrt(monthly_data['claim_count'])
        
        # Create plot with confidence intervals
        fig = go.Figure()

        # Actual total claims per month
        fig.add_trace(go.Scatter(
            x=monthly_data['date'],
            y=monthly_data['total_amount'],
            mode='lines',
            name='Total Claims',
            line=dict(color='blue')
        ))

        # Upper bound (for CI)
        fig.add_trace(go.Scatter(
            x=monthly_data['date'],
            y=monthly_data['ci_upper'],
            mode='lines',
            line=dict(width=0),
            name='Upper CI',
            showlegend=False
        ))

        # Lower bound and fill to create CI band
        fig.add_trace(go.Scatter(
            x=monthly_data['date'],
            y=monthly_data['ci_lower'],
            mode='lines',
            line=dict(width=0),
            fill='tonexty',
            fillcolor='rgba(0,100,80,0.2)',
            name='95% Confidence Interval'
        ))

        fig.update_layout(
            title='Monthly Claims with Confidence Intervals',
            xaxis_title='Month',
            yaxis_title='Total Claim Amount (KES)',
            template='plotly_white'
        )

        st.plotly_chart(fig, use_container_width=True)
    else:
        st.warning("Date or amount information not available for confidence intervals")
    
    with tab3:
        st.subheader("Impact Simulation Module")
        
        st.write("Simulate the impact of policy changes on claims costs")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Policy change sliders
            st.markdown("#### Policy Parameters")
            copay_change = st.slider(
                "Co-payment Change (%)",
                min_value=-100,
                max_value=100,
                value=0,
                step=5,
                help="Percentage change in member co-payment"
            )
            
            deductible_change = st.slider(
                "Deductible Change (%)",
                min_value=-100,
                max_value=100,
                value=0,
                step=5,
                help="Percentage change in annual deductible"
            )
            
            utilization_change = st.slider(
                "Expected Utilization Change (%)",
                min_value=-50,
                max_value=50,
                value=0,
                step=1,
                help="Expected change in healthcare utilization"
            )
        
        with col2:
            # Display simulated impact
            st.markdown("#### Simulated Impact")
            
            # Calculate base metrics
            total_claims = len(client_data)
            total_amount = client_data['amount'].sum()
            avg_amount = client_data['amount'].mean()
            
            # Simulate impact (simplified for demo)
            new_total = total_amount * (1 + (utilization_change/100)) * (1 - (copay_change/200)) * (1 - (deductible_change/300))
            savings = total_amount - new_total
            
            st.metric("Current Total Claims Cost", f"KES {total_amount:,.2f}")
            st.metric("Projected Total Claims Cost", f"KES {new_total:,.2f}", 
                     delta=f"KES {savings:,.2f} ({savings/total_amount*100:.1f}%)")
            
            # Show breakdown
            st.markdown("##### Impact Breakdown")
            st.write(f"- Co-payment change: {copay_change}%")
            st.write(f"- Deductible change: {deductible_change}%")
            st.write(f"- Utilization change: {utilization_change}%")
    
    with tab4:
        st.subheader("Model Explainability")
        
        st.write("""
        Understanding how the model makes predictions:
        
        - **SHAP Values**: Show the contribution of each feature to individual predictions
        - **Partial Dependence Plots**: Show the relationship between a feature and the predicted outcome
        """)
        
        # Example SHAP values (in a real app, you'd calculate these from your model)
        st.markdown("#### SHAP Value Analysis")
        
        # Create example SHAP values for demo
        if 'category' in client_data.columns and 'amount' in client_data.columns:
            categories = client_data['category'].value_counts().index[:5]
            shap_values = {
                'Feature': ['Age', 'Gender', 'Diagnosis', 'Provider', 'Category'],
                'SHAP Value': [0.3, 0.1, 0.4, 0.2, 0.5]
            }
            
            fig = px.bar(
                pd.DataFrame(shap_values).sort_values('SHAP Value', ascending=True),
                x='SHAP Value',
                y='Feature',
                orientation='h',
                title='Feature Importance (SHAP Values)',
                color='SHAP Value',
                color_continuous_scale='Blues'
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Partial dependence plot example
            st.markdown("#### Partial Dependence Plot")
            
            # Generate example data
            age_range = np.arange(20, 80, 5)
            pd_values = 1000 + age_range * 50  # Linear relationship for demo
            
            fig = px.line(
                x=age_range,
                y=pd_values,
                title='Partial Dependence on Age',
                labels={'x': 'Age', 'y': 'Predicted Claim Amount (KES)'}
            )
            
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.warning("Insufficient data for explainability analysis")

# ==============================================
# FRAUD DETECTION
# ==============================================

def render_fraud_detection(user_info):
    """Render the fraud detection section"""
    st.header("🕵️ Fraud Detection")
    
    # Check if data is loaded
    if 'claims_data' not in st.session_state or st.session_state.claims_data is None:
        st.warning("Please upload claims data first")
        return
    
    data = st.session_state.claims_data
    
    # Filter data for this client
    client_data = data[data['employer'] == user_info['client_org']].copy()
    
    if client_data.empty:
        st.warning("No claims data found for your organization")
        return
    
    # Check if fraud detection has been run - if not, run it
    if 'fraud_flag' not in client_data.columns:
        with st.spinner("Running initial fraud detection..."):
            client_data = detect_fraud_anomalies(client_data)
            st.session_state.claims_data = data  # Update the original data
    
    # Summary metrics
    col1, col2, col3 = st.columns(3)
    with col1:
        fraud_count = client_data['fraud_flag'].sum()
        st.metric("⚠️ Potential Fraud Cases", fraud_count)
    with col2:
        fraud_rate = fraud_count / len(client_data)
        st.metric("Fraud Rate", f"{fraud_rate:.1%}")
    with col3:
        fraud_amount = client_data.loc[client_data['fraud_flag'] == 1, 'amount'].sum()
        st.metric("Amount at Risk", f"KES {fraud_amount:,.2f}")
    
    # Tabbed interface
    tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
        "Risk Scores",
        "Suspicious Providers",
        "Diagnosis Patterns",
        "Monthly Trends",
        "Potential Cases",
        "Geospatial Heatmap"
    ])
    
    with tab1:
        st.subheader("Fraud Risk Scores")
        
        if 'fraud_score' in client_data.columns:
            # Show top risky claims
            risky_claims = client_data.sort_values('fraud_score', ascending=True).head(20)
            
            # Format the table
            gb = GridOptionsBuilder.from_dataframe(risky_claims[[
                'date', 'amount', 'provider_name', 'diagnosis', 'fraud_score'
            ]])
            
            # Apply conditional formatting to fraud score
            gb.configure_columns([
                {'field': 'fraud_score', 'cellStyle': {'color': 'white', 'backgroundColor': '#d62728'}}
            ])
            
            gb.configure_pagination(paginationAutoPageSize=True)
            gb.configure_side_bar()
            gb.configure_selection('single', use_checkbox=True)
            grid_options = gb.build()
            
            AgGrid(
                risky_claims,
                gridOptions=grid_options,
                data_return_mode='AS_INPUT',
                update_mode='MODEL_CHANGED',
                fit_columns_on_grid_load=True,
                height=400
            )
        else:
            st.warning("Fraud risk scores not calculated")
    
    with tab2:
        st.subheader("Top Suspicious Providers")
        
        if 'provider_name' in client_data.columns and 'fraud_flag' in client_data.columns:
            provider_fraud = client_data.groupby('provider_name').agg({
                'amount': 'sum',
                'fraud_flag': ['sum', 'count']
            }).reset_index()
            
            provider_fraud.columns = ['Provider', 'Total Amount', 'Fraud Count', 'Total Claims']
            provider_fraud['Fraud Rate'] = provider_fraud['Fraud Count'] / provider_fraud['Total Claims']
            
            # Show top fraudulent providers
            top_fraud = provider_fraud.sort_values('Fraud Count', ascending=False).head(10)
            
            fig = px.bar(
                top_fraud,
                x='Provider',
                y='Fraud Count',
                color='Fraud Rate',
                title="Top Providers by Fraud Count",
                hover_data=['Total Amount', 'Total Claims']
            )
            
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.warning("Provider information not available")
    
    with tab3:
        st.subheader("Fraud Patterns by Diagnosis")
        
        if 'diagnosis' in client_data.columns and 'fraud_flag' in client_data.columns:
            diagnosis_fraud = client_data.groupby('diagnosis').agg({
                'amount': 'sum',
                'fraud_flag': ['sum', 'count']
            }).reset_index()
            
            diagnosis_fraud.columns = ['Diagnosis', 'Total Amount', 'Fraud Count', 'Total Claims']
            diagnosis_fraud['Fraud Rate'] = diagnosis_fraud['Fraud Count'] / diagnosis_fraud['Total Claims']
            
            # Show diagnoses with highest fraud rates
            high_fraud_diag = diagnosis_fraud[diagnosis_fraud['Total Claims'] > 10].sort_values(
                'Fraud Rate', ascending=False).head(10)
            
            if not high_fraud_diag.empty:
                fig = px.bar(
                    high_fraud_diag,
                    x='Diagnosis',
                    y='Fraud Rate',
                    color='Total Amount',
                    title="Diagnoses with Highest Fraud Rates",
                    hover_data=['Total Claims', 'Fraud Count']
                )
                
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.warning("Insufficient data for diagnosis analysis")
        else:
            st.warning("Diagnosis information not available")
    
    with tab4:
        st.subheader("Monthly Fraud Trends")
        
        if 'date' in client_data.columns and 'fraud_flag' in client_data.columns:
            client_data['date'] = pd.to_datetime(client_data['date'])
            fraud_over_time = client_data.set_index('date').resample('M')['fraud_flag'].sum().reset_index()
            
            fig = px.line(
                fraud_over_time,
                x='date',
                y='fraud_flag',
                title="Monthly Fraud Cases",
                markers=True
            )
            
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.warning("Date information not available")
    
    with tab5:
        st.subheader("Potential Fraud Cases")
        
        if 'fraud_flag' in client_data.columns:
            fraud_cases = client_data[client_data['fraud_flag'] == 1]
            
            # Configure AgGrid for interactive table
            gb = GridOptionsBuilder.from_dataframe(fraud_cases)
            gb.configure_pagination(paginationAutoPageSize=True)
            gb.configure_side_bar()
            gb.configure_selection('multiple', use_checkbox=True)
            grid_options = gb.build()
            
            grid_response = AgGrid(
                fraud_cases,
                gridOptions=grid_options,
                height=500,
                width='100%',
                data_return_mode='AS_INPUT',
                update_mode='MODEL_CHANGED',
                fit_columns_on_grid_load=True,
                theme='streamlit'
            )
            
            # Action buttons for selected rows
            selected = grid_response['selected_rows']
            if selected:
                st.markdown("### Actions for Selected Claims")
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    if st.button("Flag for Review"):
                        st.success(f"{len(selected)} claims flagged for review")
                
                with col2:
                    if st.button("Export Selected"):
                        selected_df = pd.DataFrame(selected)
                        csv = selected_df.to_csv(index=False).encode('utf-8')
                        
                        st.download_button(
                            label="Download as CSV",
                            data=csv,
                            file_name="flagged_claims.csv",
                            mime="text/csv"
                        )
                
                with col3:
                    if st.button("View Details"):
                        st.write(selected)
        else:
            st.warning("Fraud detection not run on this data")
    
    with tab6:
        st.subheader("Geospatial Fraud Heatmap")
        
        if 'latitude' in client_data.columns and 'longitude' in client_data.columns and 'fraud_flag' in client_data.columns:
            fraud_data = client_data[client_data['fraud_flag'] == 1]
            
            if not fraud_data.empty:
                fig = px.density_mapbox(
                    fraud_data,
                    lat='latitude',
                    lon='longitude',
                    z='amount',
                    radius=10,
                    center=dict(lat=fraud_data['latitude'].mean(), lon=fraud_data['longitude'].mean()),
                    zoom=10,
                    mapbox_style="stamen-terrain",
                    title='Fraud Claim Density by Location'
                )
                
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.warning("No fraudulent claims with location data")
        else:
            st.warning("Geospatial coordinates not available")

# ==============================================
# REPORTING
# ==============================================

def render_reporting(user_info):
    """Render the reporting section"""
    st.header("📑 Reporting")
    
    # Check if data is loaded
    if 'claims_data' not in st.session_state or st.session_state.claims_data is None:
        st.warning("Please upload claims data first")
        return
    
    data = st.session_state.claims_data
    
    # Filter data for this client
    client_data = data[data['employer'] == user_info['client_org']].copy()
    
    if client_data.empty:
        st.warning("No claims data found for your organization")
        return
    
    # Tabbed interface
    tab1, tab2, tab3 = st.tabs([
        "Download Reports",
        "Claim Drilldown",
        "Custom Filters"
    ])
    
    with tab1:
        st.subheader("Downloadable Reports")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### Claims Forecast Report")
            st.write("Comprehensive report of claims forecasting and predictions")
            
            if st.button("Generate Forecast Report"):
                # Generate PDF report
                pdf_bytes = generate_pdf_report(client_data, "Forecast")
                
                # Generate Excel report
                excel_data = generate_excel_report(client_data, "Forecast")
                
                # Download buttons
                st.download_button(
                    label="Download PDF",
                    data=pdf_bytes,
                    file_name="claims_forecast_report.pdf",
                    mime="application/pdf"
                )
                
                st.download_button(
                    label="Download Excel",
                    data=excel_data,
                    file_name="claims_forecast_data.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )
        
        with col2:
            st.markdown("#### Fraud Detection Report")
            st.write("Detailed analysis of potential fraud cases")
            
            if st.button("Generate Fraud Report"):
                # Generate PDF report
                pdf_bytes = generate_pdf_report(client_data, "Fraud")
                
                # Generate Excel report
                excel_data = generate_excel_report(client_data, "Fraud")
                
                # Download buttons
                st.download_button(
                    label="Download PDF",
                    data=pdf_bytes,
                    file_name="fraud_detection_report.pdf",
                    mime="application/pdf"
                )
                
                st.download_button(
                    label="Download Excel",
                    data=excel_data,
                    file_name="fraud_detection_data.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )
    
    with tab2:
        st.subheader("Claim-Level Drilldown")
        
        # Configure AgGrid for interactive table
        gb = GridOptionsBuilder.from_dataframe(client_data)
        gb.configure_pagination(paginationAutoPageSize=True)
        gb.configure_side_bar()
        gb.configure_selection('multiple', use_checkbox=True)
        grid_options = gb.build()
        
        grid_response = AgGrid(
            client_data,
            gridOptions=grid_options,
            height=500,
            width='100%',
            data_return_mode='AS_INPUT',
            update_mode='MODEL_CHANGED',
            fit_columns_on_grid_load=True,
            theme='streamlit'
        )
        
        # Export selected rows
        selected = grid_response['selected_rows']
        if selected:
            st.markdown("### Export Selected Claims")
            selected_df = pd.DataFrame(selected)
            
            col1, col2 = st.columns(2)
            
            with col1:
                # CSV export
                csv = selected_df.to_csv(index=False).encode('utf-8')
                st.download_button(
                    label="Download as CSV",
                    data=csv,
                    file_name="selected_claims.csv",
                    mime="text/csv"
                )
            
            with col2:
                # Excel export
                output = BytesIO()
                with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
                    selected_df.to_excel(writer, index=False, sheet_name='Selected Claims')
                
                st.download_button(
                    label="Download as Excel",
                    data=output.getvalue(),
                    file_name="selected_claims.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )
    
    with tab3:
        st.subheader("Custom Filters")
        
        st.write("Create custom views of your claims data")
        
        # Filter options
        col1, col2 = st.columns(2)
        
        with col1:
            # Date range filter
            if 'date' in client_data.columns:
                min_date = pd.to_datetime(client_data['date']).min().to_pydatetime()
                max_date = pd.to_datetime(client_data['date']).max().to_pydatetime()
                
                date_range = st.date_input(
                    "Date Range",
                    value=[min_date, max_date],
                    min_value=min_date,
                    max_value=max_date
                )
            else:
                st.warning("Date information not available")
            
            # Amount range filter
            if 'amount' in client_data.columns:
                min_amount = float(client_data['amount'].min())
                max_amount = float(client_data['amount'].max())
                
                amount_range = st.slider(
                    "Amount Range (KES)",
                    min_value=min_amount,
                    max_value=max_amount,
                    value=(min_amount, max_amount)
                )
            else:
                st.warning("Amount information not available")
        
        with col2:
            # Category filter
            if 'category' in client_data.columns:
                categories = st.multiselect(
                    "Benefit Categories",
                    options=client_data['category'].unique(),
                    default=client_data['category'].unique()
                )
            else:
                st.warning("Category information not available")
            
            # Provider filter
            if 'provider_name' in client_data.columns:
                providers = st.multiselect(
                    "Providers",
                    options=client_data['provider_name'].unique(),
                    default=client_data['provider_name'].unique()
                )
            else:
                st.warning("Provider information not available")
        
        # Apply filters
        filtered_data = client_data.copy()
        
        if 'date' in client_data.columns and len(date_range) == 2:
            filtered_data = filtered_data[
                (pd.to_datetime(filtered_data['date']) >= pd.to_datetime(date_range[0])) & 
                (pd.to_datetime(filtered_data['date']) <= pd.to_datetime(date_range[1]))
            ]
        if 'amount' in client_data.columns:
            filtered_data = filtered_data[
                (filtered_data['amount'] >= amount_range[0]) & 
                (filtered_data['amount'] <= amount_range[1])]
        
        if 'category' in client_data.columns and categories:
            filtered_data = filtered_data[filtered_data['category'].isin(categories)]
        
        if 'provider_name' in client_data.columns and providers:
            filtered_data = filtered_data[filtered_data['provider_name'].isin(providers)]
        
        # Show filtered results
        st.write(f"Filtered to {len(filtered_data)} claims")
        st.dataframe(filtered_data.head(100))
        
        # Export filtered data
        st.markdown("### Export Filtered Data")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # CSV export
            csv = filtered_data.to_csv(index=False).encode('utf-8')
            st.download_button(
                label="Download as CSV",
                data=csv,
                file_name="filtered_claims.csv",
                mime="text/csv"
            )
        
        with col2:
            # Excel export
            output = BytesIO()
            with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
                filtered_data.to_excel(writer, index=False, sheet_name='Filtered Claims')
            
            st.download_button(
                label="Download as Excel",
                data=output.getvalue(),
                file_name="filtered_claims.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )

# ==============================================
# HELPER FUNCTIONS
# ==============================================

def detect_fraud_anomalies(df):
    """Detect potential fraud using isolation forest"""
    try:
        # Select numeric columns for anomaly detection
        numeric_cols = df.select_dtypes(include=['float64', 'int64']).columns.tolist()
        
        if not numeric_cols:
            df['fraud_flag'] = 0
            df['fraud_score'] = 0
            return df
        
        # Train isolation forest
        from sklearn.ensemble import IsolationForest
        from sklearn.preprocessing import StandardScaler
        
        model = IsolationForest(contamination=0.05, random_state=42)
        amounts = df[numeric_cols].values
        scaler = StandardScaler()
        amounts_scaled = scaler.fit_transform(amounts)
        
        df['fraud_score'] = model.fit_predict(amounts_scaled)
        df['fraud_flag'] = np.where(df['fraud_score'] == -1, 1, 0)
        
        return df
    except Exception as e:
        logging.error(f"Fraud detection failed: {str(e)}")
        df['fraud_flag'] = 0
        df['fraud_score'] = 0
        return df

def generate_pdf_report(data, report_type):
    """Generate a PDF report from the data"""
    from fpdf import FPDF
    import tempfile
    import os
    
    pdf = FPDF()
    pdf.add_page()
    
    # Header
    pdf.set_font('Arial', 'B', 16)
    pdf.cell(0, 10, f'Claims {report_type} Report', 0, 1, 'C')
    pdf.set_font('Arial', '', 12)
    pdf.cell(0, 10, f'Generated on {datetime.now().strftime("%Y-%m-%d")}', 0, 1, 'C')
    pdf.ln(10)
    
    # Summary metrics
    pdf.set_font('Arial', 'B', 14)
    pdf.cell(0, 10, 'Summary Metrics', 0, 1)
    pdf.set_font('Arial', '', 12)
    
    # Calculate metrics
    total_claims = len(data)
    total_amount = data['amount'].sum() if 'amount' in data.columns else 0
    avg_amount = total_amount / total_claims if total_claims > 0 else 0
    fraud_count = data['fraud_flag'].sum() if 'fraud_flag' in data.columns else 0
    
    pdf.cell(0, 10, f'Total Claims: {total_claims:,}', 0, 1)
    pdf.cell(0, 10, f'Total Amount: KES {total_amount:,.2f}', 0, 1)
    pdf.cell(0, 10, f'Average Claim: KES {avg_amount:,.2f}', 0, 1)
    
    if report_type == "Fraud":
        pdf.cell(0, 10, f'Potential Fraud Cases: {fraud_count:,}', 0, 1)
    
    pdf.ln(10)
    
    # Time series chart if available
    if 'date' in data.columns and 'amount' in data.columns:
        try:
            # Create plot
            import matplotlib.pyplot as plt
            data['date'] = pd.to_datetime(data['date'])
            monthly_data = data.set_index('date').resample('M')['amount'].sum().reset_index()
            
            plt.figure(figsize=(8, 4))
            plt.plot(monthly_data['date'], monthly_data['amount'])
            plt.title('Monthly Claims Value')
            plt.ylabel('Amount (KES)')
            plt.grid(True, linestyle='--', alpha=0.7)
            plt.tight_layout()
            
            # Save plot to temp file
            with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmp:
                plt.savefig(tmp.name, dpi=150)
                tmp_path = tmp.name
            
            # Insert into PDF
            pdf.image(tmp_path, x=10, y=pdf.get_y(), w=180)
            pdf.ln(80)
            
            # Clean up
            plt.close()
            os.unlink(tmp_path)
        except Exception as e:
            pdf.cell(0, 10, f"Could not generate time series: {str(e)}", 0, 1)
    
    # Footer
    pdf.set_y(-15)
    pdf.set_font('Arial', 'I', 8)
    pdf.cell(0, 10, f'Page {pdf.page_no()}', 0, 0, 'C')
    
    return pdf.output(dest='S').encode('latin1')

def generate_excel_report(data, report_type):
    """Generate an Excel report from the data"""
    output = BytesIO()
    
    with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
        # Summary sheet
        summary_data = {
            'Metric': ['Total Claims', 'Total Amount', 'Average Claim'],
            'Value': [len(data), data['amount'].sum(), data['amount'].mean()]
        }
        
        if report_type == "Fraud":
            summary_data['Metric'].append('Potential Fraud Cases')
            summary_data['Value'].append(data['fraud_flag'].sum() if 'fraud_flag' in data.columns else 0)
        
        pd.DataFrame(summary_data).to_excel(writer, sheet_name='Summary', index=False)
        
        # Data sheet
        data.to_excel(writer, sheet_name='Claims Data', index=False)
        
        # Additional sheets for fraud report
        if report_type == "Fraud" and 'fraud_flag' in data.columns:
            fraud_data = data[data['fraud_flag'] == 1]
            fraud_data.to_excel(writer, sheet_name='Fraud Cases', index=False)
            
            if 'provider_name' in data.columns:
                provider_stats = data.groupby('provider_name').agg({
                    'amount': 'sum',
                    'fraud_flag': ['sum', 'count']
                }).reset_index()
                provider_stats.columns = ['Provider', 'Total Amount', 'Fraud Count', 'Total Claims']
                provider_stats.to_excel(writer, sheet_name='Provider Analysis', index=False)
    
    return output.getvalue()

# ==============================================
# MAIN EXECUTION
# ==============================================

if __name__ == "__main__":
    # Example usage (in a real app, this would be called from your main app)
    user_info = {
        'name': 'Acme Admin',
        'client_org': 'Acme Corp',
        'role': 'client'
    }
    
    # Load sample data (in a real app, this would come from your data pipeline)
    sample_data = pd.DataFrame({
        'date': pd.date_range('2023-01-01', periods=100),
        'amount': np.random.normal(1000, 300, 100),
        'category': np.random.choice(['Inpatient', 'Outpatient', 'Pharmacy', 'Dental'], 100),
        'cost_centre': np.random.choice(['HR', 'Finance', 'Operations', 'IT'], 100),
        'benefit_type': np.random.choice(['Medical', 'Dental', 'Vision', 'Mental Health'], 100),
        'employee_id': np.random.randint(1000, 1100, 100),
        'provider_name': np.random.choice(['Hospital A', 'Clinic B', 'Pharmacy C', 'Lab D'], 100),
        'diagnosis': np.random.choice(['Flu', 'Back Pain', 'Diabetes', 'Hypertension'], 100),
        'treatment': np.random.choice(['Consultation', 'Medication', 'Procedure', 'Test'], 100),
        'latitude': np.random.uniform(-1.5, 1.5, 100),
        'longitude': np.random.uniform(34.5, 36.5, 100),
        'employer': 'Acme Corp'
    })
    
    # Add some fraud flags for demo
    sample_data['fraud_flag'] = np.random.choice([0, 1], 100, p=[0.95, 0.05])
    sample_data['fraud_score'] = np.random.uniform(-1, 0, 100)
    
    # Store in session state
    st.session_state.claims_data = sample_data
    
    # Run the portal
    client_portal(user_info)